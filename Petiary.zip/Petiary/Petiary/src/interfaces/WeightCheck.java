package interfaces;

import java.text.SimpleDateFormat;

public interface WeightCheck {
	
	public boolean checkWeight();
	
}
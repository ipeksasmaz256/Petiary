package interfaces;

import java.text.SimpleDateFormat;

public interface SimpleDate {
	final static SimpleDateFormat sdf = new SimpleDateFormat("dd/M/yyyy");
}
